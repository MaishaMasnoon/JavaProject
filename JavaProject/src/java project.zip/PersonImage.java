import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class PersonImage {
	private BufferedImage image = null;
	private static int persondiameter = 90;
	public static int x = 100;
	public static int y = SecondPanel.height - 200;
	
	//private static int speed = 2;
	//private int accelaration = 1;
	
	public PersonImage(){
		LoadImage();
	}

	private void LoadImage() {
		try{
			image = ImageIO.read(new File("C:/Users/Md.NizamulHaq/workspace/JavaProject/Images/walking2.jpg"));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		
	}
	public void drawPerson(Graphics g){
		g.drawImage(image, x, y, null);
	}
	/*public void personMovement(){
		//if(x>=0 && x<=SecondPanel.width)
			if(x>=0){
			//speed +=accelaration;
			x+=3;
		}
	}*/
	public void jump(){
		
			y-=15;
			x+=6;
			
	}
	public void goDown(){
	
			y+=15;
			x+=6;
			
	}
	public static Rectangle getPersonRect(){
		Rectangle personRect = new Rectangle(x,y,persondiameter,100);
		return personRect;
	}
}
