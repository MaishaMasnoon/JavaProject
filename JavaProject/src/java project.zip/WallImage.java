import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class WallImage {
	private BufferedImage image = null;
	private static int wall_width = 30;
	private static int wall_Height = 170;
	public  int x;
	public static int y = SecondPanel.height - 200;
	public static int speed = -6;
	
	public WallImage(int x){
		this.x=x;
		LoadImage();
	}

	private void LoadImage() {
		try{
			image = ImageIO.read(new File("C:/Users/Md.NizamulHaq/workspace/JavaProject/Images/wall1.png"));
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public void drawWall(Graphics g){
		g.drawImage(image, x, y, null);
	}
	public void wallMoving(){
		x+=speed;
		if(x<=-wall_width){
			x=SecondPanel.width;
			y = SecondPanel.height - 200;
			wall_Height = 170;
		}
		
		Rectangle wallRect = new Rectangle(x,y,wall_width, wall_Height);
		
		if(wallRect.intersects(PersonImage.getPersonRect())){
			
		}
	}
}
