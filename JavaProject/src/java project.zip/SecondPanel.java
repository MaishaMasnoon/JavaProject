import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class SecondPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int width = 600;
	public static final int height = 800;
	
	private int x = 0;
	private BufferedImage image;
	
	PersonImage pi = new PersonImage();
	
	WallImage wi = new WallImage(SecondPanel.width);
	WallImage wi2 = new WallImage(SecondPanel.width+(SecondPanel.width/2));
	
	public SecondPanel(){
		LoadImage();
		
		this.addMouseListener(new MouseAdapter(){
			public void mousePressed(MouseEvent e){
				super.mousePressed(e);
				pi.jump();
			}
			/*public void mouseReleased(MouseEvent e){
				super.mouseReleased(e);
				pi.goDown();
			}*/
		});
		
		/*this.addKeyListener(new KeyListener() {
			
			
			
			public void keyTyped(KeyEvent e) {
				//System.out.println(e.getKeyChar());
				
			}
			public void keyPressed(KeyEvent e) {
				System.out.println(e.getKeyChar());
					int code = e.getKeyCode();
					if(code==KeyEvent.VK_UP){
						System.out.println("Up arrow");
						int i;
						System.out.println("Up arrow");
						for(i=0;i<10;i++){
						y-=10;
						x+=6;
						repaint();}
						pi.jump();
					}
					
					
				}
			
			
			public void keyReleased(KeyEvent e) {
				System.out.println(e.getKeyChar());
				
				int code = e.getKeyCode();
				if(code==KeyEvent.VK_UP){
					System.out.println("Up arrow");
				int i;
				System.out.println("Up arrow");
				for(i=0;i<10;i++){
				y+=10;
				x+=6;
				repaint();}
				pi.goDown();
				}
			}
			
		
		});*/
		
	}

	private void LoadImage() {
		try{
			image = ImageIO.read(new File("C:/Users/Md.NizamulHaq/workspace/JavaProject/Images/pic5.jpg"));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}
	public void paint(Graphics g){
		super.paint(g);
		
		g.drawImage(image,x,0, null);
		g.drawImage(image,x+2400,0, null);
		
		pi.drawPerson(g);
		wi.drawWall(g);
		wi2.drawWall(g);
	}
	public void move(){
		//pi.personMovement();
		wi.wallMoving();
		wi2.wallMoving();
		
		x+=WallImage.speed;
		if(x==-2400){
			x=0;
		}
	}
	
	

	
	
}
